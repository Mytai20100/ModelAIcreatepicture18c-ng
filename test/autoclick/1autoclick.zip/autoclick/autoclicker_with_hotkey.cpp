#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <Richedit.h>   // RichEdit control
#include <gdiplus.h>    // GDI+ for images
#include <iostream>      // For console output

// Constants for command IDs
enum {
    ID_START = 1,
    ID_STOP,
    ID_HOTKEY,
    ID_CHANGE_BG
};

// Global variables
HWND hCpsInput, hStartButton, hStopButton, hHotkeyButton, hHotkeyDisplay, hOutputTerminal, hBackgroundButton;
int running = 0;
int cps = 10; // Default CPS
int hotkey = 0; // Hotkey code
int isSelectingHotkey = 0; // Flag for hotkey selection
HANDLE hThread = NULL; // Thread for auto-clicking
Gdiplus::Image *backgroundImage = NULL; // For GDI+ background image
ULONG_PTR gdiplusToken; // GDI+ token
CRITICAL_SECTION cs; // Critical section for thread safety

// Function to load required libraries
int LoadRequiredLibraries() {
    // Load GDI+
    Gdiplus::GdiplusStartupInput gdiplusStartupInput;
    Gdiplus::Status status = Gdiplus::GdiplusStartup(&gdiplusToken, &gdiplusStartupInput, NULL);
    if (status != Gdiplus::Ok) {
        MessageBox(NULL, "GDI+ is not available. Please install the GDI+ library.", "Error", MB_OK | MB_ICONERROR);
        return 0;
    }

    // Load RichEdit
    HMODULE hRichEdit = LoadLibrary("Msftedit.dll");
    if (!hRichEdit) {
        MessageBox(NULL, "RichEdit control is not available. Please install the RichEdit control.", "Error", MB_OK | MB_ICONERROR);
        Gdiplus::GdiplusShutdown(gdiplusToken);
        return 0;
    }

    return 1;
}

// Function to check if required libraries are available
int CheckLibraries() {
    if (!LoadRequiredLibraries()) return 0;
    return 1;
}

// Auto clicker function
DWORD WINAPI AutoClicker(LPVOID lpParam) {
    while (running) {
        mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0);
        mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);
        Sleep(1000 / cps);
    }
    return 0;
}

// Function to update the start button
void ToggleStartButton(int isRunning) {
    SetWindowText(hStartButton, isRunning ? "Loading..." : "Start");
}

// Function to set background image
void SetBackgroundImage(const wchar_t* imagePath, HWND hwnd) {
    Gdiplus::Image* newImage = Gdiplus::Image::FromFile(imagePath);
    if (newImage && newImage->GetLastStatus() == Gdiplus::Ok) {
        // Clean up existing background image
        if (backgroundImage) {
            delete backgroundImage;
        }
        backgroundImage = newImage;
        InvalidateRect(hwnd, NULL, TRUE);
    } else {
        MessageBox(hwnd, "Failed to load background image.", "Error", MB_OK | MB_ICONERROR);
        delete newImage;
    }
}

// Function to paint background image
void PaintBackground(HWND hwnd, HDC hdc) {
    if (backgroundImage) {
        Gdiplus::Graphics graphics(hdc);
        Gdiplus::Rect rect(0, 0, 300, 200); // Adjust as needed
        graphics.DrawImage(backgroundImage, rect);
    }
}

// Window procedure
LRESULT CALLBACK WindowProcedure(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    char buffer[10];
    PAINTSTRUCT ps;
    HDC hdc;

    switch (msg) {
    case WM_COMMAND:
        if (LOWORD(wp) == ID_START) { // Start button clicked
            if (!running) {
                running = 1;
                GetWindowText(hCpsInput, buffer, sizeof(buffer));
                cps = atoi(buffer);
                if (cps < 1) cps = 1; // Minimum CPS is 1
                hThread = CreateThread(NULL, 0, AutoClicker, NULL, 0, NULL);
                ToggleStartButton(1);
            }
        } else if (LOWORD(wp) == ID_STOP) { // Stop button clicked
            if (running) {
                running = 0;
                WaitForSingleObject(hThread, INFINITE);
                CloseHandle(hThread);
                hThread = NULL;
                ToggleStartButton(0);
            }
        } else if (LOWORD(wp) == ID_HOTKEY) { // Hotkey button clicked
            isSelectingHotkey = 1;
            SetWindowText(hHotkeyDisplay, "Press any key...");
        } else if (LOWORD(wp) == ID_CHANGE_BG) { // Change background button clicked
            SetBackgroundImage(L"path_to_your_image.jpg", hwnd);
        }
        break;

    case WM_KEYDOWN:
        if (isSelectingHotkey) {
            hotkey = (int)wp; // Capture hotkey
            char hotkeyText[20];
            sprintf(hotkeyText, "Hotkey: %d", hotkey);
            SetWindowText(hHotkeyDisplay, hotkeyText);
            isSelectingHotkey = 0;
        } else if ((int)wp == hotkey) {
            SendMessage(hwnd, running ? WM_COMMAND : WM_COMMAND, ID_STOP, 0);
        }
        break;

    case WM_PAINT:
        hdc = BeginPaint(hwnd, &ps);
        PaintBackground(hwnd, hdc);
        EndPaint(hwnd, &ps);
        break;

    case WM_DESTROY:
        running = 0;
        if (hThread) {
            WaitForSingleObject(hThread, INFINITE);
            CloseHandle(hThread);
        }
        if (backgroundImage) {
            delete backgroundImage;
        }
        Gdiplus::GdiplusShutdown(gdiplusToken);
        PostQuitMessage(0);
        break;

    default:
        return DefWindowProc(hwnd, msg, wp, lp);
    }
    return 0;
}

// GUI creation function
void CreateGUI(HINSTANCE hInst, HWND hwnd) {
    CreateWindow("STATIC", "CPS:", WS_VISIBLE | WS_CHILD, 20, 20, 50, 20, hwnd, NULL, hInst, NULL);
    hCpsInput = CreateWindow("EDIT", "10", WS_VISIBLE | WS_CHILD | WS_BORDER, 80, 20, 50, 20, hwnd, NULL, hInst, NULL);
    hStartButton = CreateWindow("BUTTON", "Start", WS_VISIBLE | WS_CHILD, 150, 20, 100, 30, hwnd, (HMENU)ID_START, hInst, NULL);
    hStopButton = CreateWindow("BUTTON", "Stop", WS_VISIBLE | WS_CHILD, 150, 60, 100, 30, hwnd, (HMENU)ID_STOP, hInst, NULL);
    hHotkeyButton = CreateWindow("BUTTON", "Set Hotkey", WS_VISIBLE | WS_CHILD, 150, 100, 100, 30, hwnd, (HMENU)ID_HOTKEY, hInst, NULL);
    hHotkeyDisplay = CreateWindow("STATIC", "Hotkey: None", WS_VISIBLE | WS_CHILD, 20, 100, 120, 20, hwnd, NULL, hInst, NULL);
    
    // Terminal output area (using RichEdit control)
    hOutputTerminal = CreateWindow("RICHEDIT50W", "", WS_VISIBLE | WS_CHILD | ES_MULTILINE | WS_VSCROLL | ES_AUTOVSCROLL, 20, 150, 250, 100, hwnd, NULL, hInst, NULL);

    // Background image change button
    hBackgroundButton = CreateWindow("BUTTON", "Change Background", WS_VISIBLE | WS_CHILD, 150, 260, 130, 30, hwnd, (HMENU)ID_CHANGE_BG, hInst, NULL);
}

// Main function
int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrevInst, LPSTR lpCmdLine, int nCmdShow) {
    if (!CheckLibraries()) return 0;

    InitializeCriticalSection(&cs); // Initialize critical section

    // Create window class
    WNDCLASS wc = {};
    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = WindowProcedure;
    wc.hInstance = hInst;
    wc.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wc.lpszClassName = "AutoClickerClass";
    RegisterClass(&wc);

    // Create the main window
    HWND hwnd = CreateWindow("AutoClickerClass", "Auto Clicker with Hotkey", WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, 300, 400, NULL, NULL, hInst, NULL);
    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);

    // Create GUI components
    CreateGUI(hInst, hwnd);

    // Message loop
    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    DeleteCriticalSection(&cs); // Clean up
    return (int)msg.wParam;
}